import type { QuoteStatus } from "@/database/constants/quote-status";
import type { MissionType } from "@/database/constants/mission-type";
import type { IAircraft } from "./aircraft";

export interface IQuoteContactInfo {
  fullName: string;
  email: string;
  phone: string;
  company?: string;
}

export interface IQuoteReviewer {
  _id: string;
  firstName: string;
  lastName: string;
  email: string;
}

export interface IQuoteCustomer {
  _id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
}

export interface IQuoteAttachment {
  publicId: string;
  resourceType: "image" | "raw";
  fileName: string;
  fileType: string;
  // Signed, short-lived Cloudinary URL generated server-side at
  // request time (see getSignedAttachmentUrl). Never persisted.
  viewUrl: string;
}

export interface IQuote {
  _id: string;
  quoteNumber: string;
  customer?: string | IQuoteCustomer;
  contactInfo: IQuoteContactInfo;

  passengerCount: number;
  departureAirportCode: string;
  destinationAirportCode: string;
  departureDate: string;
  returnDate?: string;
  isRoundTrip: boolean;
  // Customer's stated preference at request time (a broad window like
  // "morning", or an exact "HH:MM" time) — see departureTimePreference
  // on the Quote model. Shown to the admin as a hint when approving;
  // not the confirmed time.
  departureTimePreference?: string;

  aircraftPreference?: string | IAircraft;
  missionType: MissionType;
  budgetRangeMin?: number;
  budgetRangeMax?: number;
  currency: string;

  specialRequests?: string;
  hasMedicalEquipment: boolean;
  medicalEquipmentDetails?: string;
  hasVipRequirements: boolean;
  vipRequirementsDetails?: string;
  hasCargo: boolean;
  cargoDetails?: string;
  hasPets: boolean;
  petsDetails?: string;
  hasDangerousGoods: boolean;
  dangerousGoodsDetails?: string;

  attachments: IQuoteAttachment[];

  status: QuoteStatus;
  adminNotes?: string;
  quotedAmount?: number;
  quotedCurrency?: string;
  validUntil?: string;
  rejectionReason?: string;
  reviewedBy?: string | IQuoteReviewer;
  reviewedAt?: string;
  selectedAircraft?: string | IAircraft;
  // Confirmed departure time ("HH:MM", 24-hour), set by the admin at
  // approval alongside the aircraft and price — see departureTime on
  // the Quote model. Distinct from departureTimePreference, which is
  // the customer's stated preference at request time.
  departureTime?: string;
  convertedBooking?: string;

  createdAt: string;
  updatedAt: string;
}