"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { Container } from "@/components/layout/container/Container";
import { TripSearchBar, type TripSearchBarValues } from "@/components/quote/TripSearchBar";

// Same sessionStorage draft shape/key CharterRequestForm restores from on
// mount (see charterRequestDraft:v1 there) — writing to it here means the
// homepage bar and the /request-charter page's own search bar are really
// the same "step 1", just entered from two different places. No new
// prefill plumbing needed on the request-charter route itself.
const DRAFT_STORAGE_KEY = "charterRequestDraft:v1";

const DEFAULT_VALUES: TripSearchBarValues = {
  departureAirportCode: "",
  destinationAirportCode: "",
  departureDate: "",
  returnDate: undefined,
  isRoundTrip: false,
  departureTimePreference: undefined,
  passengerCount: 1,
};

/**
 * "PLAN A FLIGHT" banner — modeled on VistaJet's homepage charter-request
 * opener: a short eyebrow + line of copy, then the From/To/Date/Passengers
 * bar as the sole call to action. This is deliberately just step 1 of the
 * request flow (trip details, no contact fields) — submitting hands off
 * to /request-charter, which is where CharterRequestForm's step 2
 * (contact info) lives.
 */
export function PlanAFlightBanner() {
  const router = useRouter();
  const [values, setValues] = useState<TripSearchBarValues>(DEFAULT_VALUES);
  const [isNavigating, setIsNavigating] = useState(false);

  function handleChange<K extends keyof TripSearchBarValues>(field: K, value: TripSearchBarValues[K]) {
    // Mirrors CharterRequestForm's handling of the same field: an empty
    // string return date (e.g. round-trip toggled back off) should read
    // as "not set", not as a literal empty-string date.
    const nextValue = field === "returnDate" && value === "" ? undefined : value;
    setValues((current) => ({ ...current, [field]: nextValue }) as TripSearchBarValues);
  }

  function handleSubmit() {
    setIsNavigating(true);
    try {
      window.sessionStorage.setItem(
        DRAFT_STORAGE_KEY,
        JSON.stringify({ step: 1, trip: values, contact: {} }),
      );
    } catch {
      // Private browsing / storage quota — worst case the customer just
      // re-enters trip details on the next page instead of them carrying
      // over, which is fine.
    }
    router.push("/request-charter");
  }

  return (
    <Container className="pb-0 pt-6 sm:pt-8 lg:pt-10">
      <p className="font-mono text-xl font-medium uppercase tracking-[0.28em] text-champagne-600 sm:text-2xl">Plan a Flight</p>

      <p className="mt-4 max-w-2xl font-body text-xs leading-relaxed text-champagne-600 sm:whitespace-nowrap sm:text-sm">
        Tell us your route and dates — our operations team will confirm pricing and availability shortly.
      </p>

      <div className="mt-6 sm:mt-8">
        <TripSearchBar values={values} onChange={handleChange} onSubmit={handleSubmit} isSubmitting={isNavigating} />
      </div>
    </Container>
  );
}