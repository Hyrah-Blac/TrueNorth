import type { Metadata } from "next";
import { AirplaneTakeoff } from "@phosphor-icons/react/dist/ssr";
import { BookingCard } from "@/components/booking/BookingCard/BookingCard";
import { BookingsTable } from "@/components/booking/BookingCard/BookingsTable";
import { EmptyState } from "@/components/shared/empty-state/EmptyState";
import { Button } from "@/components/shared/buttons/Button";
import { PageHeader } from "@/components/dashboard/PageHeader";
import { StatusFilterTabs } from "@/components/dashboard/StatusFilterTabs";
import { getMyBookings } from "@/features/booking/lib/getBookings";
import { getAirportNamesByCodes } from "@/lib/api/airportNames";
import { getBookingIdsWithTickets } from "@/features/ticket/lib/getTicketForBooking";
import { BOOKING_STATUS_VALUES, BOOKING_STATUS_LABELS, type BookingStatus } from "@/database/constants/booking-status";

export const metadata: Metadata = { title: "My Bookings" };

interface BookingsPageProps {
  searchParams: Promise<{ status?: string }>;
}

export default async function BookingsPage({ searchParams }: BookingsPageProps) {
  const params = await searchParams;
  const status = BOOKING_STATUS_VALUES.includes(params.status as BookingStatus)
    ? (params.status as BookingStatus)
    : undefined;

  const bookings = await getMyBookings(status);
  const [ticketedBookingIds, airportNames] = await Promise.all([
    getBookingIdsWithTickets(bookings.map((b) => b._id)),
    getAirportNamesByCodes(bookings.flatMap((b) => [b.departureAirportCode, b.destinationAirportCode])),
  ]);

  const filterOptions = [
    { label: "All", href: "/dashboard/bookings", active: !status },
    ...BOOKING_STATUS_VALUES.map((value) => ({
      label: BOOKING_STATUS_LABELS[value],
      href: `/dashboard/bookings?status=${value}`,
      active: status === value,
    })),
  ];

  return (
    <div>
      <PageHeader
        variant="light"
        title="Your Bookings"
        description="Every confirmed charter, from first departure to final invoice."
      />
      <StatusFilterTabs options={filterOptions} />

      <div className="mt-7">
        {bookings.length === 0 ? (
          <EmptyState
            icon={<AirplaneTakeoff className="h-5 w-5 text-champagne-500" aria-hidden="true" />}
            title="No bookings found"
            description="Bookings appear here once a charter request has been approved."
            action={
              <Button href="/request-charter" variant="outline">
                Request a Charter
              </Button>
            }
          />
        ) : (
          <>
            <BookingsTable bookings={bookings} airportNames={airportNames} />
            <div className="space-y-4 md:hidden">
              {bookings.map((booking) => (
                <BookingCard key={booking._id} booking={booking} hasTicket={ticketedBookingIds.has(booking._id)} airportNames={airportNames} />
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}