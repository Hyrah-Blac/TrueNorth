import { z } from "zod";

/**
 * Validated environment variables. Add new keys here as each phase
 * needs them, rather than reading process.env directly elsewhere.
 */
const envSchema = z.object({
  NODE_ENV: z.enum(["development", "production", "test"]).default("development"),
  NEXT_PUBLIC_APP_URL: z.string().url().default("http://localhost:3000"),

  MONGODB_URI: z.string().min(1, "MONGODB_URI is required"),

  NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY: z.string().min(1, "Clerk publishable key is required"),
  CLERK_SECRET_KEY: z.string().min(1, "Clerk secret key is required"),
  CLERK_WEBHOOK_SIGNING_SECRET: z.string().min(1, "Clerk webhook signing secret is required"),

  // Tells Clerk where the app's own sign-in/sign-up pages and post-auth
  // landing routes live. Without these, Clerk falls back to its own
  // defaults during flows like the OAuth sign-in/sign-up "transfer"
  // step, which can bounce users back to the wrong page after Google
  // sign-in completes.
  NEXT_PUBLIC_CLERK_SIGN_IN_URL: z.string().min(1).default("/sign-in"),
  NEXT_PUBLIC_CLERK_SIGN_UP_URL: z.string().min(1).default("/sign-up"),
  NEXT_PUBLIC_CLERK_AFTER_SIGN_IN_URL: z.string().min(1).default("/dashboard"),
  NEXT_PUBLIC_CLERK_AFTER_SIGN_UP_URL: z.string().min(1).default("/dashboard"),

  MPESA_ENVIRONMENT: z.enum(["sandbox", "production"]).default("production"),
  MPESA_CONSUMER_KEY: z.string().min(1, "M-Pesa consumer key is required"),
  MPESA_CONSUMER_SECRET: z.string().min(1, "M-Pesa consumer secret is required"),
  MPESA_SHORTCODE: z.string().min(1, "M-Pesa shortcode is required"),
  MPESA_PASSKEY: z.string().min(1, "M-Pesa passkey is required"),
  MPESA_CALLBACK_URL: z.string().url("M-Pesa callback URL must be a full https URL"),

  // Paystack is the primary online payment provider (M-Pesa + cards).
  // There is no separate webhook secret to configure — Paystack signs
  // webhook payloads with an HMAC of the same secret key used for API
  // calls (see src/lib/api/paystack.ts verifyWebhookSignature).
  PAYSTACK_SECRET_KEY: z.string().min(1, "Paystack secret key is required"),
  NEXT_PUBLIC_PAYSTACK_PUBLIC_KEY: z.string().min(1, "Paystack public key is required"),

  NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME: z.string().min(1, "Cloudinary cloud name is required"),
  CLOUDINARY_API_KEY: z.string().min(1, "Cloudinary API key is required"),
  CLOUDINARY_API_SECRET: z.string().min(1, "Cloudinary API secret is required"),

  RESEND_API_KEY: z.string().min(1, "Resend API key is required"),
  RESEND_FROM_EMAIL: z.string().email("RESEND_FROM_EMAIL must be a valid email address"),
  ADMIN_NOTIFICATION_EMAIL: z.string().email("ADMIN_NOTIFICATION_EMAIL must be a valid email address"),

  CRON_SECRET: z.string().min(16, "CRON_SECRET should be a long random string"),

  GEMINI_API_KEY: z.string().min(1, "GEMINI_API_KEY is required"),
  GEMINI_MODEL: z.string().min(1, "GEMINI_MODEL is required"),

  // Optional: only set when Clerk is configured with a custom Frontend
  // API domain (see buildCspHeader in src/lib/security/headers.ts).
  CLERK_FRONTEND_API_DOMAIN: z.string().min(1).optional(),
});

export type Env = z.infer<typeof envSchema>;

/**
 * Minimal schema for values needed in the Edge Middleware runtime
 * (src/middleware.ts -> buildCspHeader). Deliberately separate from
 * envSchema above: middleware runs on nearly every request, so if it
 * validated the full app schema (Mongo, M-Pesa, Paystack, Cloudinary,
 * Resend, Cron, Gemini, ...), a single missing/malformed unrelated
 * secret would throw inside middleware and take down every route on
 * the site with MIDDLEWARE_INVOCATION_FAILED - even though none of
 * those values are used there. Add a key here ONLY if middleware (or
 * other edge code) actually reads it.
 */
const middlewareEnvSchema = z.object({
  CLERK_FRONTEND_API_DOMAIN: z.string().min(1).optional(),
});

export type MiddlewareEnv = z.infer<typeof middlewareEnvSchema>;

let cachedMiddlewareEnv: MiddlewareEnv | null = null;

export function getMiddlewareEnv(): MiddlewareEnv {
  if (cachedMiddlewareEnv) return cachedMiddlewareEnv;

  const parsed = middlewareEnvSchema.safeParse({
    CLERK_FRONTEND_API_DOMAIN: process.env.CLERK_FRONTEND_API_DOMAIN,
  });

  if (!parsed.success) {
    const issues = parsed.error.issues
      .map((issue) => `  - ${issue.path.join(".")}: ${issue.message}`)
      .join("\n");
    throw new Error(`Invalid middleware environment configuration:\n${issues}`);
  }

  cachedMiddlewareEnv = parsed.data;
  return cachedMiddlewareEnv;
}

let cachedEnv: Env | null = null;

export function getEnv(): Env {
  if (cachedEnv) return cachedEnv;

  const parsed = envSchema.safeParse({
    NODE_ENV: process.env.NODE_ENV,
    NEXT_PUBLIC_APP_URL: process.env.NEXT_PUBLIC_APP_URL,
    MONGODB_URI: process.env.MONGODB_URI,
    NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY: process.env.NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY,
    CLERK_SECRET_KEY: process.env.CLERK_SECRET_KEY,
    CLERK_WEBHOOK_SIGNING_SECRET: process.env.CLERK_WEBHOOK_SIGNING_SECRET,
    NEXT_PUBLIC_CLERK_SIGN_IN_URL: process.env.NEXT_PUBLIC_CLERK_SIGN_IN_URL,
    NEXT_PUBLIC_CLERK_SIGN_UP_URL: process.env.NEXT_PUBLIC_CLERK_SIGN_UP_URL,
    NEXT_PUBLIC_CLERK_AFTER_SIGN_IN_URL: process.env.NEXT_PUBLIC_CLERK_AFTER_SIGN_IN_URL,
    NEXT_PUBLIC_CLERK_AFTER_SIGN_UP_URL: process.env.NEXT_PUBLIC_CLERK_AFTER_SIGN_UP_URL,
    MPESA_ENVIRONMENT: process.env.MPESA_ENVIRONMENT,
    MPESA_CONSUMER_KEY: process.env.MPESA_CONSUMER_KEY,
    MPESA_CONSUMER_SECRET: process.env.MPESA_CONSUMER_SECRET,
    MPESA_SHORTCODE: process.env.MPESA_SHORTCODE,
    MPESA_PASSKEY: process.env.MPESA_PASSKEY,
    MPESA_CALLBACK_URL: process.env.MPESA_CALLBACK_URL,
    PAYSTACK_SECRET_KEY: process.env.PAYSTACK_SECRET_KEY,
    NEXT_PUBLIC_PAYSTACK_PUBLIC_KEY: process.env.NEXT_PUBLIC_PAYSTACK_PUBLIC_KEY,
    NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME: process.env.NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME,
    CLOUDINARY_API_KEY: process.env.CLOUDINARY_API_KEY,
    CLOUDINARY_API_SECRET: process.env.CLOUDINARY_API_SECRET,
    RESEND_API_KEY: process.env.RESEND_API_KEY,
    RESEND_FROM_EMAIL: process.env.RESEND_FROM_EMAIL,
    ADMIN_NOTIFICATION_EMAIL: process.env.ADMIN_NOTIFICATION_EMAIL,
    CRON_SECRET: process.env.CRON_SECRET,
    GEMINI_API_KEY: process.env.GEMINI_API_KEY,
    GEMINI_MODEL: process.env.GEMINI_MODEL,
    CLERK_FRONTEND_API_DOMAIN: process.env.CLERK_FRONTEND_API_DOMAIN,
  });

  if (!parsed.success) {
    const issues = parsed.error.issues
      .map((issue) => `  - ${issue.path.join(".")}: ${issue.message}`)
      .join("\n");
    throw new Error(`Invalid environment configuration:\n${issues}`);
  }

  cachedEnv = parsed.data;
  return cachedEnv;
}